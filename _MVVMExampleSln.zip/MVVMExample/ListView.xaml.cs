﻿namespace MVVMExample
{
    public partial class ListView
    {
        public ListView()
        {
            InitializeComponent();
        }
    }
}
